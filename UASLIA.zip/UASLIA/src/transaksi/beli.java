
package transaksi;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class beli extends javax.swing.JFrame {
    DefaultTableModel table = new DefaultTableModel();

    
    public beli() {
        initComponents();
        tb_keranjang.setModel(table);
        table.addColumn("id_cust");
        table.addColumn("Kode");
        table.addColumn("Nama");
        table.addColumn("Jenis");
        table.addColumn("Stok");
        table.addColumn("Harga");
        table.addColumn("Jumlah");
        table.addColumn("Total");
    tampilData();
    }
    
    private void tampilData(){
        //untuk mengahapus baris setelah input
        int row = tb_keranjang.getRowCount();
        for(int a = 0 ; a < row ; a++){
            table.removeRow(0);
        }
        
        try{
        String query = "SELECT * FROM `customer` ";
        
            Connection connect = Connect.getKoneksi();//memanggil koneksi
            Statement sttmnt = connect.createStatement();//membuat statement
            ResultSet rslt = sttmnt.executeQuery(query);//menjalanakn query
            
            while (rslt.next()){
                //menampung data sementara
                    String id = rslt.getString("id_cust");
                    String kode = rslt.getString("kode");
                    String nama = rslt.getString("nama_obat");
                    String jenis = rslt.getString("jenis");
                    String stok = rslt.getString("stok");
                    String harga = rslt.getString("harga");
                    String jumlah = rslt.getString("jumlah");
                    String total = rslt.getString("total_harga");
                    
                //masukan semua data kedalam array
                String[] keranjang = {id,kode,nama,jenis,stok,harga,jumlah, total};
                //menambahakan baris sesuai dengan data yang tersimpan diarray
                table.addRow(keranjang);
            }
                //mengeset nilai yang ditampung agar muncul di table
                tb_keranjang.setModel(table);
                
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    private void clear(){
        txt_id.setText(null);
        txt_kode.setText(null);
        txt_nama.setText(null);
        txt_harga.setText(null);
        txt_stok.setText(null);
        txt_jenis.setText(null);
        txt_jumlah2.setText(null);
        txt_subtotal.setText(null);
    }    
    
    private void keranjang(){
        String id = txt_id.getText();
        String kode = txt_kode.getText();
        String stok = txt_stok.getText();
        String nama = txt_nama.getText();
        String jenis = txt_jenis.getText();
        String harga = txt_harga.getText();
        String jumlah = txt_jumlah2.getText();
        String total = txt_subtotal.getText();

        
        try{
        //panggil koneksi
        Connection connect = Connect.getKoneksi();
        //query untuk memasukan data
        String query = "INSERT INTO `customer` (`id_cust`, `kode`, `nama_obat`, `jenis`,`stok`, `harga`, `jumlah`, `total_harga`)"
                + "VALUES ('"+id+"','"+kode+"', '"+nama+"', '"+jenis+"', '"+stok+"', '"+harga+"', '"+jumlah+"',  '"+total+"')";
        
            //menyiapkan statement untuk di eksekusi
            PreparedStatement ps = (PreparedStatement) connect.prepareStatement(query);
            ps.executeUpdate(query);
            JOptionPane.showMessageDialog(null,"Data Masuk Ke-Keranjang");
            
        }catch(SQLException | HeadlessException e){
            System.out.println(e);
            JOptionPane.showMessageDialog(null,"Data Gagal Disimpan");
//            e.printStackTrace();
        }finally{
            tampilData();
            clear();
        }
        autosum();
    }
   
    
    
    public void autosum(){
        int total = 0;
        for (int i = 0; i < tb_keranjang.getRowCount();i++){
        int amount = Integer.parseInt((String)tb_keranjang.getValueAt(i, 7));
        total +=amount;
        }
        txt_totalharga.setText(""+total);
    }

    
    private void stok(){
        Connection connect = Connect.getKoneksi();//memanggil koneksi
        int stok = Integer.parseInt(txt_stok.getText());
        int jumlahbeli = Integer.parseInt(txt_jumlah2.getText());

        if(jumlahbeli > stok){
            JOptionPane.showMessageDialog(null, "Stok Tidak Tersedia!!");
            clear();
            
        }if(jumlahbeli >= 1){   
            int sisastok = (stok-jumlahbeli);
               String query = "UPDATE data_obat SET stok = '" +sisastok+ "' WHERE kode = '" +txt_kode.getText()+ "'" ;
               try{
                   PreparedStatement ps = (PreparedStatement) connect.prepareStatement(query);
                   ps.executeUpdate();
                }catch(SQLException | HeadlessException e){
                   System.out.println(e);
                   JOptionPane.showMessageDialog(null, "");
                }finally{
                   keranjang();
               }
        }else {
            JOptionPane.showMessageDialog(null, "Invalid Input!!");
            }    
    }

    
    private void user(){
        String user = txt_id.getText();
        
        try{
            int iduser = Integer.parseInt(user);
            String id = Integer.toString(iduser);
            txt_id.setText(id);

        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Only Number");
            txt_id.setText(null);
        }
    }
    
    private void total(){
        String harga = txt_harga.getText();
        String jumlah = txt_jumlah2.getText();
        
        int hargaa = Integer.parseInt(harga);
        try{
        int jumlahh = Integer.parseInt(jumlah);
        
        int total = hargaa * jumlahh;
        String total_harga = Integer.toString(total);
        
        txt_subtotal.setText(total_harga);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Only Number");
            txt_jumlah2.setText(null);
        }
    }

    
    private void kembalian(){
        int NominalUang = Integer.parseInt(txt_uang.getText());
        int TotalHarga = Integer.parseInt(txt_totalharga.getText());
            if (NominalUang >= TotalHarga){
                txt_kembalian.setText(Integer.toString(NominalUang - TotalHarga));
                    JOptionPane.showMessageDialog(null, "Transaksi Berhasil!");
            }else {
            JOptionPane.showMessageDialog(null, "Maaf uang tidak cukup");
            }      
            // klo mau pake reset ini bisa langsung tehapus juga tanpa kita klik reset tpi itu klo ga mau pake struk bisa gitu
//        reset(); 
    }
    
    
    private void reset(){
        try{
            String clear = "TRUNCATE `customer`";
            Connection connect = Connect.getKoneksi();
            PreparedStatement ps = (PreparedStatement) connect.prepareStatement(clear);
            ps.execute();
//            keranjang();

        }catch(Exception e){
            System.out.println(e);
        }finally{
            tampilData();
            txt_uang.setText(null);
            txt_kembalian.setText(null);
    }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txt_subtotal = new javax.swing.JTextField();
        txt_jumlah2 = new javax.swing.JTextField();
        Add = new javax.swing.JButton();
        txt_nama = new javax.swing.JTextField();
        txt_harga = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb_keranjang = new javax.swing.JTable();
        txt_totalharga = new javax.swing.JTextField();
        txt_uang = new javax.swing.JTextField();
        Bayar = new javax.swing.JButton();
        txt_kembalian = new javax.swing.JTextField();
        Lihat = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        txt_kode = new javax.swing.JTextField();
        txt_stok = new javax.swing.JTextField();
        reset = new javax.swing.JButton();
        txt_id = new javax.swing.JTextField();
        txt_jenis = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_subtotal.setEditable(false);
        txt_subtotal.setBackground(java.awt.Color.white);
        txt_subtotal.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_subtotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_subtotalActionPerformed(evt);
            }
        });
        getContentPane().add(txt_subtotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(641, 180, 110, 50));

        txt_jumlah2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_jumlah2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_jumlah2ActionPerformed(evt);
            }
        });
        txt_jumlah2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_jumlah2KeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_jumlah2KeyTyped(evt);
            }
        });
        getContentPane().add(txt_jumlah2, new org.netbeans.lib.awtextra.AbsoluteConstraints(312, 180, 110, 50));

        Add.setBackground(new java.awt.Color(204, 204, 255));
        Add.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        Add.setText("  ADD");
        Add.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddMouseClicked(evt);
            }
        });
        Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddActionPerformed(evt);
            }
        });
        getContentPane().add(Add, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, 160, 40));

        txt_nama.setEditable(false);
        txt_nama.setBackground(java.awt.Color.white);
        txt_nama.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_nama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_namaActionPerformed(evt);
            }
        });
        getContentPane().add(txt_nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(402, 87, 110, 50));

        txt_harga.setEditable(false);
        txt_harga.setBackground(java.awt.Color.white);
        txt_harga.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_harga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_hargaActionPerformed(evt);
            }
        });
        getContentPane().add(txt_harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(475, 180, 110, 50));

        tb_keranjang.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tb_keranjang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tb_keranjang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_keranjangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tb_keranjang);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 250, 500, 200));

        txt_totalharga.setEditable(false);
        txt_totalharga.setBackground(java.awt.Color.white);
        txt_totalharga.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_totalharga.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_totalharga.setEnabled(false);
        txt_totalharga.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                txt_totalhargaMouseReleased(evt);
            }
        });
        txt_totalharga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_totalhargaActionPerformed(evt);
            }
        });
        getContentPane().add(txt_totalharga, new org.netbeans.lib.awtextra.AbsoluteConstraints(304, 485, 110, 50));

        txt_uang.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_uang.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_uang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_uangActionPerformed(evt);
            }
        });
        txt_uang.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_uangKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_uangKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_uangKeyTyped(evt);
            }
        });
        getContentPane().add(txt_uang, new org.netbeans.lib.awtextra.AbsoluteConstraints(478, 485, 110, 50));

        Bayar.setBackground(new java.awt.Color(204, 204, 255));
        Bayar.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        Bayar.setText("  PAYMENT");
        Bayar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BayarMouseClicked(evt);
            }
        });
        Bayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BayarActionPerformed(evt);
            }
        });
        getContentPane().add(Bayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, 160, 40));

        txt_kembalian.setEditable(false);
        txt_kembalian.setBackground(java.awt.Color.white);
        txt_kembalian.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        txt_kembalian.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_kembalian.setEnabled(false);
        txt_kembalian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_kembalianActionPerformed(evt);
            }
        });
        getContentPane().add(txt_kembalian, new org.netbeans.lib.awtextra.AbsoluteConstraints(651, 485, 110, 50));

        Lihat.setBackground(new java.awt.Color(204, 204, 255));
        Lihat.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        Lihat.setText("  LIHAT DATA");
        Lihat.setToolTipText("");
        Lihat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LihatMouseClicked(evt);
            }
        });
        Lihat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LihatActionPerformed(evt);
            }
        });
        getContentPane().add(Lihat, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, 160, 40));

        jButton4.setBackground(new java.awt.Color(255, 153, 153));
        jButton4.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jButton4.setText("  LOGOUT");
        jButton4.setToolTipText("");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 490, 130, 50));

        txt_kode.setEditable(false);
        txt_kode.setBackground(java.awt.Color.white);
        txt_kode.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_kode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_kodeActionPerformed(evt);
            }
        });
        getContentPane().add(txt_kode, new org.netbeans.lib.awtextra.AbsoluteConstraints(262, 87, 110, 50));

        txt_stok.setEditable(false);
        txt_stok.setBackground(java.awt.Color.white);
        txt_stok.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_stok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_stokActionPerformed(evt);
            }
        });
        getContentPane().add(txt_stok, new org.netbeans.lib.awtextra.AbsoluteConstraints(684, 87, 110, 50));

        reset.setBackground(new java.awt.Color(204, 204, 255));
        reset.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        reset.setText("  RESET");
        reset.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                resetMouseClicked(evt);
            }
        });
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });
        getContentPane().add(reset, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 400, 160, 40));

        txt_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_idActionPerformed(evt);
            }
        });
        txt_id.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_idKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_idKeyTyped(evt);
            }
        });
        getContentPane().add(txt_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 170, 90, 30));

        txt_jenis.setEditable(false);
        txt_jenis.setBackground(java.awt.Color.white);
        txt_jenis.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        txt_jenis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_jenisActionPerformed(evt);
            }
        });
        getContentPane().add(txt_jenis, new org.netbeans.lib.awtextra.AbsoluteConstraints(542, 87, 110, 50));

        jLabel2.setForeground(new java.awt.Color(101, 76, 35));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/foto/Menu Cust.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 820, 570));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_subtotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_subtotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_subtotalActionPerformed

    private void txt_jumlah2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_jumlah2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_jumlah2ActionPerformed

    private void txt_jumlah2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_jumlah2KeyReleased
        // TODO add your handling code here:
        total();
    }//GEN-LAST:event_txt_jumlah2KeyReleased

    private void txt_jumlah2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_jumlah2KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_jumlah2KeyTyped

    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
        
        stok();
    }//GEN-LAST:event_AddActionPerformed

    private void txt_namaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_namaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_namaActionPerformed

    private void txt_hargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_hargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_hargaActionPerformed

    private void tb_keranjangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_keranjangMouseClicked
//        int row = tb_keranjang.getSelectedRow();
//        beli menu = new beli();
//        
//        String id = tb_keranjang.getValueAt(row, 0).toString();
//        txt_id.setText(id);
//        
//        String kode = tb_keranjang.getValueAt(row, 1).toString();
//        txt_kode.setText(kode);
//        
//        String nama = tb_keranjang.getValueAt(row, 2).toString();
//        txt_nama.setText(nama);
//        
//        String jenis = tb_keranjang.getValueAt(row, 3).toString();
//        txt_jenis.setText(jenis);
//        
//        String stok = tb_keranjang.getValueAt(row, 4).toString();
//        txt_stok.setText(stok);
//        
//        String harga = tb_keranjang.getValueAt(row, 5).toString();
//        txt_harga.setText(harga);
//        
//        String jumlah = tb_keranjang.getValueAt(row, 6).toString();
//        txt_jumlah2.setText(jumlah);
//        
//        String total = tb_keranjang.getValueAt(row, 7).toString();
//        txt_subtotal.setText(total);
    }//GEN-LAST:event_tb_keranjangMouseClicked

    private void txt_totalhargaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_totalhargaMouseReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_totalhargaMouseReleased

    private void txt_totalhargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_totalhargaActionPerformed
//        totalnya();
    }//GEN-LAST:event_txt_totalhargaActionPerformed

    private void txt_uangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_uangActionPerformed
           
    }//GEN-LAST:event_txt_uangActionPerformed

    private void txt_uangKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_uangKeyPressed
        // TODO add your handling code here:

    }//GEN-LAST:event_txt_uangKeyPressed

    private void txt_uangKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_uangKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_uangKeyReleased

    private void txt_uangKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_uangKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_uangKeyTyped

    private void BayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BayarActionPerformed
        kembalian();
    }//GEN-LAST:event_BayarActionPerformed

    private void txt_kembalianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_kembalianActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_kembalianActionPerformed

    private void LihatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LihatMouseClicked
        // TODO add your handling code here:
        new data().setVisible(true);
        dispose();
    }//GEN-LAST:event_LihatMouseClicked

    private void LihatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LihatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_LihatActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        new welcome ().show();
            this.dispose();

    }//GEN-LAST:event_jButton4ActionPerformed

    private void txt_kodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_kodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_kodeActionPerformed

    private void AddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_AddMouseClicked

    private void BayarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BayarMouseClicked
        kembalian();
    }//GEN-LAST:event_BayarMouseClicked

    private void txt_stokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_stokActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_stokActionPerformed

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed

    }//GEN-LAST:event_resetActionPerformed

    private void resetMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_resetMouseClicked
        reset();
    }//GEN-LAST:event_resetMouseClicked

    private void txt_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_idActionPerformed

    private void txt_jenisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_jenisActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_jenisActionPerformed

    private void txt_idKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_idKeyTyped

    }//GEN-LAST:event_txt_idKeyTyped

    private void txt_idKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_idKeyReleased
        user();
    }//GEN-LAST:event_txt_idKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(beli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(beli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(beli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(beli.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
         @Override
         public void run() {
                new beli().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JButton Bayar;
    private javax.swing.JButton Lihat;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton reset;
    private javax.swing.JTable tb_keranjang;
    public javax.swing.JTextField txt_harga;
    private javax.swing.JTextField txt_id;
    public javax.swing.JTextField txt_jenis;
    public javax.swing.JTextField txt_jumlah2;
    public static javax.swing.JTextField txt_kembalian;
    public javax.swing.JTextField txt_kode;
    public javax.swing.JTextField txt_nama;
    public javax.swing.JTextField txt_stok;
    public javax.swing.JTextField txt_subtotal;
    public static javax.swing.JTextField txt_totalharga;
    public static javax.swing.JTextField txt_uang;
    // End of variables declaration//GEN-END:variables
}
