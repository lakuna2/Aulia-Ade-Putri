
package transaksi;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Admin extends javax.swing.JFrame {
    DefaultTableModel table = new DefaultTableModel();
    
    public Admin() {
        initComponents();
        table.addColumn("Kode");
        table.addColumn("Nama");
        table.addColumn("Gol_Obat");
        table.addColumn("Jens");
        table.addColumn("Stok");
        table.addColumn("Harga");
        tTabel.setModel(table);
        tampiltabel();
        
        clear_form();
    }
    
        private void clear_form() {
        tKode.setText(null);
        tNama.setText(null);
        tGol.setText(null);
        tJenis.setSelectedItem(this);
        tStok.setText(null);
        tharga.setText(null);
        }

   
         public void tampiltabel(){
            int row = tTabel.getRowCount();
                for(int a = 0 ; a < row ; a++){
                    table.removeRow(0);
            }
        
            String query = "SELECT * FROM `data_obat` ";
        
       try{
            Connection connect = transaksi.Connect.getKoneksi();//memanggil koneksi
            java.sql.Statement sttmnt = connect.createStatement();//membuat statement
            ResultSet rslt = sttmnt.executeQuery(query);//menjalanakn query
            
            while (rslt.next()){
                //menampung data sementara
                   
                    String kode = rslt.getString("kode");
                    String nama = rslt.getString("nama_obat");
                    String gol = rslt.getString("gol_obat");
                    String jenis = rslt.getString("jenis");
                    String stok = rslt.getString("stok");
                    String harga = rslt.getString("harga");
                    
                    
                //masukan semua data kedalam array
                String[] data = {kode,nama,gol,jenis,stok,harga};
                //menambahakan baris sesuai dengan data yang tersimpan diarray
                table.addRow(data);
            }
                //mengeset nilai yang ditampung agar muncul di table
                tTabel.setModel(table);
            
        }catch(Exception e){
            System.out.println(e);
        }
       
   }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tNama = new javax.swing.JTextField();
        tStok = new javax.swing.JTextField();
        tJenis = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tTabel = new javax.swing.JTable();
        tTambah = new javax.swing.JButton();
        tUpdate = new javax.swing.JButton();
        tHapus = new javax.swing.JButton();
        tLogout = new javax.swing.JButton();
        tKode = new javax.swing.JTextField();
        tharga = new javax.swing.JTextField();
        tGol = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tNamaActionPerformed(evt);
            }
        });
        getContentPane().add(tNama, new org.netbeans.lib.awtextra.AbsoluteConstraints(467, 121, 120, 50));
        getContentPane().add(tStok, new org.netbeans.lib.awtextra.AbsoluteConstraints(464, 222, 120, 50));

        tJenis.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tJenis.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Serbuk", "Tablet", "Cair", "Pil", "Kapsul" }));
        getContentPane().add(tJenis, new org.netbeans.lib.awtextra.AbsoluteConstraints(302, 222, 120, 50));

        tTabel.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.gray, java.awt.Color.darkGray));
        tTabel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tTabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tTabelMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tTabel);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 310, 500, 230));

        tTambah.setBackground(new java.awt.Color(204, 204, 255));
        tTambah.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tTambah.setText("Tambah Data");
        tTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tTambahActionPerformed(evt);
            }
        });
        getContentPane().add(tTambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, 160, 40));

        tUpdate.setBackground(new java.awt.Color(204, 204, 255));
        tUpdate.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tUpdate.setText("Update Data");
        tUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tUpdateActionPerformed(evt);
            }
        });
        getContentPane().add(tUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, 160, 40));

        tHapus.setBackground(new java.awt.Color(204, 204, 255));
        tHapus.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tHapus.setText("Hapus Data");
        tHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tHapusActionPerformed(evt);
            }
        });
        getContentPane().add(tHapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 330, 160, 40));

        tLogout.setBackground(new java.awt.Color(255, 153, 153));
        tLogout.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tLogout.setText("LOGOUT");
        tLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tLogoutActionPerformed(evt);
            }
        });
        getContentPane().add(tLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 500, 120, 50));

        tKode.setToolTipText("");
        tKode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tKodeActionPerformed(evt);
            }
        });
        getContentPane().add(tKode, new org.netbeans.lib.awtextra.AbsoluteConstraints(302, 121, 120, 50));

        tharga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thargaActionPerformed(evt);
            }
        });
        getContentPane().add(tharga, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 222, 120, 50));

        tGol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tGolActionPerformed(evt);
            }
        });
        getContentPane().add(tGol, new org.netbeans.lib.awtextra.AbsoluteConstraints(631, 119, 120, 50));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/foto/Menu Admin.png"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 820, 570));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tNamaActionPerformed

    private void tLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tLogoutActionPerformed
        // TODO add your handling code here:
        new welcome().show();
        this.dispose();
//        System.exit(0);
    }//GEN-LAST:event_tLogoutActionPerformed

    private void tTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tTambahActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "INSERT INTO data_obat VALUES ('"+tKode.getText()+"','"+tNama.getText()+"','"+tGol.getText()+"','"+tJenis.getSelectedItem()+"','"+tStok.getText()+"','"+tharga.getText()+"')";
            java.sql.Connection con = (Connection)Connect.getKoneksi();
            java.sql.PreparedStatement pstm = con.prepareStatement(sql);
            pstm.execute();
             JOptionPane.showMessageDialog(null, "Tambah data berhasil");
             tampiltabel();
             clear_form();
            
        } catch (HeadlessException | SQLException e) {
         JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_tTambahActionPerformed

    private void tTabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tTabelMouseClicked
        // TODO add your handling code here:
        int row = tTabel.getSelectedRow();
        beli menu = new beli();
        
        String kode = tTabel.getValueAt(row, 0).toString();
        tKode.setText(kode);
        
        String nama = tTabel.getValueAt(row, 1).toString();
        tNama.setText(nama);
        
        String gol = tTabel.getValueAt(row, 2).toString();
        tGol.setText(gol);
        
        String jenis = tTabel.getValueAt(row, 3).toString();
        tJenis.setSelectedItem(jenis);
        
        String stok = tTabel.getValueAt(row, 4).toString();
        tStok.setText(stok);
        
        String harga = tTabel.getValueAt(row, 5).toString();
        tharga.setText(harga);
        
    }//GEN-LAST:event_tTabelMouseClicked

    private void tUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tUpdateActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "UPDATE data_obat SET kode='"+tKode.getText()+"',nama_obat='"+tNama.getText()+"',gol_obat='"+tGol.getText()+"',jenis='"+tJenis.getSelectedItem()+"',stok='"+tStok.getText()+"',harga='"+tharga.getText()+"' WHERE kode = '"+tKode.getText()+"'";
            java.sql.Connection con = (Connection)Connect.getKoneksi();
            java.sql.PreparedStatement pstm = con.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Update Data Berhasil");  
            
        } catch (HeadlessException | SQLException e) {
         JOptionPane.showMessageDialog(this, e.getMessage());
        }
         tampiltabel();
         clear_form();
    }//GEN-LAST:event_tUpdateActionPerformed

    private void tHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tHapusActionPerformed
        // TODO add your handling code here:
         try {
            String sql = "DELETE FROM data_obat WHERE kode='"+tKode.getText()+"'";
            java.sql.Connection con = (Connection)Connect.getKoneksi();
            java.sql.PreparedStatement pstm = con.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Hapus Data Berhasil");
            
        } catch (HeadlessException | SQLException e) {
         JOptionPane.showMessageDialog(this, e.getMessage());
        }
            tampiltabel();
            clear_form();
    }//GEN-LAST:event_tHapusActionPerformed

    private void tKodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tKodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tKodeActionPerformed

    private void thargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_thargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_thargaActionPerformed

    private void tGolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tGolActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tGolActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField tGol;
    private javax.swing.JButton tHapus;
    private javax.swing.JComboBox<String> tJenis;
    private javax.swing.JTextField tKode;
    private javax.swing.JButton tLogout;
    private javax.swing.JTextField tNama;
    private javax.swing.JTextField tStok;
    private javax.swing.JTable tTabel;
    private javax.swing.JButton tTambah;
    private javax.swing.JButton tUpdate;
    private javax.swing.JTextField tharga;
    // End of variables declaration//GEN-END:variables
}
