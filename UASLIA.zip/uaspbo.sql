-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2022 at 02:09 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uaspbo`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id_cust` int(11) NOT NULL,
  `kode` int(4) NOT NULL,
  `nama_obat` varchar(20) NOT NULL,
  `jenis` varchar(15) NOT NULL,
  `stok` int(4) NOT NULL,
  `harga` int(11) NOT NULL,
  `jumlah` int(3) NOT NULL,
  `total_harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `data_obat`
--

CREATE TABLE `data_obat` (
  `kode` int(4) NOT NULL,
  `nama_obat` varchar(20) NOT NULL,
  `gol_obat` varchar(10) NOT NULL,
  `jenis` varchar(15) NOT NULL,
  `stok` int(4) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_obat`
--

INSERT INTO `data_obat` (`kode`, `nama_obat`, `gol_obat`, `jenis`, `stok`, `harga`) VALUES
(1001, 'ProveVit', 'Vitamin', 'Serbuk', 50, 100000),
(1002, 'Herboost', 'Vitamin', 'Cair', 18, 135000),
(1003, 'Natur-E', 'Vitamin', 'Kapsul', 26, 50000),
(2006, 'Mylanta', 'Maag', 'Cair', 88, 20000),
(2007, 'Promag', 'Maag', 'Tablet', 51, 10000),
(2008, 'Dexanta', 'Maag', 'Cair', 60, 25000),
(5050, 'Oskadon', 'Pusing', 'Tablet', 30, 6000),
(5051, 'Vastigo', 'Pusing', 'Tablet', 62, 10000),
(5052, 'Bodrex', 'Pusing', 'Tablet', 46, 5000),
(6025, 'Diapet', 'Diare', 'Tablet', 65, 5000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD KEY `kode` (`kode`);

--
-- Indexes for table `data_obat`
--
ALTER TABLE `data_obat`
  ADD PRIMARY KEY (`kode`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`kode`) REFERENCES `data_obat` (`kode`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
